package com.example.vectormath;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GameEngine extends SurfaceView implements Runnable {
    private final String TAG = "VECTOR-MATH";

    // game thread variables
    private Thread gameThread = null;
    private volatile boolean gameIsRunning;

    // drawing variables
    private Canvas canvas;
    private Paint paintbrush;
    private SurfaceHolder holder;

    // Screen resolution varaibles
    private int screenWidth;
    private int screenHeight;

    //SET UP OBJEVTS
    Sprite bullet;
    Sprite square;
    final int SIZE = 100;

    //lets make an array of bullets
    List<Sprite> bullets = new ArrayList<Sprite>();

    public GameEngine(Context context, int screenW, int screenH) {
        super(context);

        // intialize the drawing variables
        this.holder = this.getHolder();
        this.paintbrush = new Paint();

        // set screen height and width
        this.screenWidth = screenW;
        this.screenHeight = screenH;

        //bullet = new Sprite(getContext(),100,600,SIZE,SIZE);
        //create an array of list
        for(int i = 0 ; i<10;i++)
        {
            Random r = new Random();
            int randomxpos = r.nextInt(this.screenWidth-100) +1;
            int randomypos = r.nextInt(this.screenHeight-300) + 1;
            Sprite b = new Sprite(getContext(),randomxpos,randomypos,SIZE,SIZE);
            bullets.add(b);
        }
        //square
        Random r = new Random();
        int randomxpos = r.nextInt(this.screenWidth-100) +1;
        int randomypos = r.nextInt(this.screenHeight-300) + 1;
        square = new Sprite(getContext(),randomxpos,randomypos,SIZE,SIZE);

    }

    @Override
    public void run() {
        // @TODO: Put game loop in here
        while (gameIsRunning == true) {
            updateGame();
            drawGame();
            controlFPS();
        }
    }



     boolean screenIsMovingDown = true;
     final int SquareSpeed = 20;
    // Game Loop methods
    public void updateGame() {
        /*
        Random r = new Random();
        int randomxpos = r.nextInt(this.screenWidth-100) +1;
        int randomypos = r.nextInt(this.screenHeight-300) + 1;
        square.x = randomxpos;
        square.y = randomypos;
        */

        //move the square
        if (screenIsMovingDown == true) {
            square.y = square.y + SquareSpeed;
            if (square.y >= this.screenHeight) {
                screenIsMovingDown = false;
            }
        } else {
            square.y = square.y - SquareSpeed;
            if (square.y <= 0) {
                screenIsMovingDown = true;
            }
        }

        for (int i = 0; i < bullets.size(); i++) {


             Sprite bull = bullets.get(i);
            //square.y = square.y -10;

            //bullet.x = bullet.x+10;
            //bullet move
            //calculate distance between bullet and square
            double a = (square.x - bull.x);
            double b = (square.y - bull.y);
            double distance = Math.sqrt((a * a) + (b * b));

            //calculate the rate to move
            double xn = (a / distance);
            double yn = (b / distance);

            //move the bullet
            bull.x = bull.x + (int) (xn * 15);
            bull.y = bull.y + (int) (yn * 15);
            }


    }

    public void drawGame() {
        if (holder.getSurface().isValid()) {

            // initialize the canvas
            canvas = holder.lockCanvas();
            // --------------------------------
            // @TODO: put your drawing code in this section

            // set the game's background color
            canvas.drawColor(Color.argb(255,255,255,255));

            //draw stationary box
            paintbrush.setStyle(Paint.Style.STROKE);
            paintbrush.setStrokeWidth(10);
             paintbrush.setColor(Color.MAGENTA);
            canvas.drawRect(square.x,square.y,square.x+SIZE,square.y+SIZE,paintbrush);


            //drawing bullets
            paintbrush.setStyle(Paint.Style.STROKE);
            paintbrush.setStrokeWidth(10);
            paintbrush.setColor(Color.BLACK);
            for(int i =0;i< bullets.size();i++) {

                Sprite b = bullets.get(i);

                canvas.drawRect(b.x, b.y, b.x + SIZE, b.y + SIZE, paintbrush);
            }
            // --------------------------------
            holder.unlockCanvasAndPost(canvas);
        }

    }

    public void controlFPS() {
        try {
            gameThread.sleep(17);
        }
        catch (InterruptedException e) {

        }
    }


    // Deal with user input


    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction() & MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_UP:
                   Float x =event.getX();
                   Float y =event.getY();

                   square.x = (int) event.getX();
                   square.y = (int) event.getY();
                break;
            case MotionEvent.ACTION_DOWN:

                break;
        }
        return true;
    }

    // Game status - pause & resume
    public void pauseGame() {
        gameIsRunning = false;
        try {
            gameThread.join();
        }
        catch (InterruptedException e) {

        }
    }
    public void  resumeGame() {
        gameIsRunning = true;
        gameThread = new Thread(this);
        gameThread.start();
    }

}
