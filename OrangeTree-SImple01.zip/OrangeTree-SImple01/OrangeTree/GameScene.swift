//
//  GameScene.swift
//  OrangeTree
//
//  Created by Parrot on 2019-02-19.
//  Copyright © 2019 Parrot. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene, SKPhysicsContactDelegate {

    var tree:SKSpriteNode!
    var coin:SKSpriteNode!
    var stick:SKSpriteNode!
   
    var orange:Orange!
    
    // gesture variables
    var startingTouchPosition: CGPoint = CGPoint(x:0, y:0)
    
    // draw a line
    var shapeNode = SKShapeNode()
    
    override func didMove(to view: SKView) {
        tree = self.childNode(withName: "tree") as! SKSpriteNode
        self.coin = self.childNode(withName: "coin") as! SKSpriteNode
        self.stick = self.childNode(withName: "stick") as! SKSpriteNode
        
        // setup the delegate
        self.physicsWorld.contactDelegate = self
        
        
        self.physicsBody = SKPhysicsBody(edgeLoopFrom: self.frame)
        
        //categoryBitMask
        self.physicsBody?.categoryBitMask = 8
        self.name = "wall"

        
        // configure shape node
        self.shapeNode.lineWidth = 20
        self.shapeNode.lineCap = .round
        self.shapeNode.strokeColor = UIColor(red: 0.5294, green: 0, blue: 0.5765, alpha: 0.8)
        addChild(shapeNode)
        
        
//        // setup sprite categories
//        self.coin.physicsBody?.categoryBitMask = 2
//        self.stick.physicsBody?.categoryBitMask = 4
//        self.physicsBody?.categoryBitMask = 8
//
//        // setup collision reaction rules
//        // stick will react to orange
//        self.stick.physicsBody?.collisionBitMask = 8
//        self.coin.physicsBody?.collisionBitMask = 1
    }
    
    
    /*
     CATEGORIES:
     - 0:   isDyanmic == false
     - 1:   orange
     - 2:   coin
     - 4:   stick
     - 8:   walls
     - 4294967295:  everything else

     COLLISION RULES:
        - Orange will intersect with everything
        - Coin will intersect with only oranges
        - Stick will only intersect with the wall
     
     NOTIFICATION RULES:
        - Orange will notifiy when it hits a coin + anything with category = 4294967295
     */
    
    
    
    func didBegin(_ contact: SKPhysicsContact) {
        var CurrentTime = CACurrentMediaTime()
        print("\(CurrentTime) - collision!")
        
        let objectA = contact.bodyA.node as? SKSpriteNode
        let objectB = contact.bodyB.node as? SKSpriteNode
        
        print("Object A = \(objectA?.name)")
        print("Object B = \(objectB?.name)")
        
        print("-----")
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        if (touch == nil) {
            return
        }
        
        let mousePosition = touch?.location(in: self)
        
        let spriteTouched = self.atPoint(mousePosition!)
        
        if (spriteTouched.name == "tree") {
            // spawn an orange
            orange = Orange()
            
            orange.position = mousePosition!
            orange.name = "orange"
            addChild(orange)
            
            orange.physicsBody?.isDynamic = false
            orange.physicsBody?.categoryBitMask = 1
            
            
            // set contactBitMask for orange
            // ---------------------------------
            
            //ORANGE GONNA BOUNCE BACK FROM THE GROUND ONLY!!!
            //self.orange?.physicsBody?.collisionBitMask  = 16
            
           // self.coin?.physicsBody?.collisionBitMask = 8
            
            //Listen to coin and stick
            self.orange?.physicsBody?.collisionBitMask  = 6
            
            //coin gonna react to ground and platform
            self.coin?.physicsBody?.collisionBitMask  = 16
            
            
            
            // listen for collisions on only STICKS
            //1--ORANGE 2--COIN STICK--4  GROUND ---16
    //            self.orange?.physicsBody?.contactTestBitMask = 14
            
            // listen for collisions on ALL objects
            // self.orange?.physicsBody?.contactTestBitMask = UInt32.max
            
            // listen for collisions on only COINS
           //self.orange?.physicsBody?.contactTestBitMask = 10
            
            // only SHOW collisions on rabbits
            // do not show collisions for any other sprite
            //self.orange?.physicsBody?.collisionBitMask  = 5
            
            // get the starting position of mouse
            startingTouchPosition = mousePosition!
            
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        // person raised their finger
        let touch = touches.first
        if (touch == nil) {
            return
        }
        
        let endingPosition = touch!.location(in: self)
        
        let diffX = endingPosition.x - self.startingTouchPosition.x
        let diffY = endingPosition.y - self.startingTouchPosition.y

        let direction = CGVector(dx:diffX, dy:diffY)
        
        self.orange.physicsBody?.isDynamic = true
        self.orange.physicsBody?.applyImpulse(direction)
        
        // remove the line
        self.shapeNode.path = nil

    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        if (touch == nil) {
            return
        }
        
        let mousePosition = touch!.location(in: self)
        
        orange.position = mousePosition
        
        //draw a line to show direction of orange
        let path = UIBezierPath()
        path.move(to: startingTouchPosition)
        path.addLine(to: mousePosition)
        self.shapeNode.path = path.cgPath
        
        
    }
    
    override func update(_ currentTime: TimeInterval) {
        
    }
    
    
    
}
